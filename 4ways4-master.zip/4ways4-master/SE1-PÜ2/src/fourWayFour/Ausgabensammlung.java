package fourWayFour;


public class Ausgabensammlung {
	
	
	public static void ausgabe(String s){
		System.out.println(s);
	}
}