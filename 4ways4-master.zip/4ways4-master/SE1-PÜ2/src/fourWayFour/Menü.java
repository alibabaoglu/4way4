package fourWayFour;

import java.util.*;

public class Men� {

	final static int COMPUTER = 1;
	final static int SPIELER_2 = 2;
	final static boolean spiel_beenden = false;

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		int gspieler;
		int zeilenl�nge;
		int spaltenl�nge;
		boolean g�tligeEingabe = true;

		Ausgabensammlung.ausgabe(
				"Dr�cken Sie '1' f�r ein Spiel gegen den Computer, '2' f�r ein Spiel gegen einen anderen Spieler.");
		gspieler = in.nextInt();
		if (gspieler != COMPUTER || gspieler != SPIELER_2) {
//			TODO trycatch
		}
		Ausgabensammlung.ausgabe("Geben Sie die Spaltenl�nge zwischen 7 und 10 ein.");
		spaltenl�nge = in.nextInt();
		if (spaltenl�nge < 7 || spaltenl�nge > 10) {
//			TODO ERROR
		}
		Ausgabensammlung.ausgabe("Geben Sie die Zeilenl�nge zwischen 7 und 10 ein.");
		zeilenl�nge = in.nextInt();
		if (zeilenl�nge < 7 || spaltenl�nge > 10) {
//			TODO ERROR
		}
		Ausgabensammlung.ausgabe("Eingabe: ");

		if (gspieler == COMPUTER) {
			Ausgabensammlung.ausgabe("Wenn KI anfangen soll, dann dr�cke die 3");

		} else {
//			Auswahl Spieler 1/2?
			in.close();
		}
	}
}